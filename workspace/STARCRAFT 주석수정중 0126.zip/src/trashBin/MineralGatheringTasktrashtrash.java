///*package trashBin;
//package com.taeyoun.unit;
//
//import com.taeyoun.resource.Player;
//
//
//
//public class MineralGatheringTask implements Runnable {
//	
//	private final Player player;
//	public MineralGatheringTask(Player player) {
//		this.player = player;
//	}
//	
//	@Override
//	public void run() {
//		player.increaseMinerals();
//	}
//
//}
//*/
//package trashBin;
//
