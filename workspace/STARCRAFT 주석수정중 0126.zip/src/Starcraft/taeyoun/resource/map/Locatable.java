package Starcraft.taeyoun.resource.map;

public interface Locatable {
	//x,y 좌표에 대한 getter setter
 int getX();	
 int getY();
 void setX(int x);
 void setY(int y);
}
