package Starcraft.taeyoun.unit;

public interface Move {
 void move(int x, int y);
}
