package test2;

public class DanceRobot extends Robot {
	void dance() {
		System.out.println("춤을 춥니다.");
		//1. "춤을 춥니다 ."를 출력한다.
	}
}
