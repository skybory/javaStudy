package test2;

public class DrawRobot extends Robot {
	void draw() {
		System.out.println("그림을 그립니다.");
		//2."그림을 그립니다." 를 출력한다.
	}
}
