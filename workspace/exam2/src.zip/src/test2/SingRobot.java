package test2;

public class SingRobot extends Robot {
	void sing() {
		System.out.println("노래를 합니다");
		//3. "노래를 합니다." 를 출력한다.
	}
}
