package Starcraft.taeyoun.unit;

public interface Attack {

void attack(); 
}
