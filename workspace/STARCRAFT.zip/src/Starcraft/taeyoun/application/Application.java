package Starcraft.taeyoun.application;


public class Application {
	public static void main(String[] args) {
		StartGame game = new StartGame();
		game.showGameStatus();			//게임 끝나면 실행
	}
}
