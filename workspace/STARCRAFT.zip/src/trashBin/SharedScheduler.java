/*
package com.taeyoun.application;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import com.taeyoun.resource.Player;

public class SharedScheduler {
	//스케쥴러 크래스, timer의 간섭때문에 만듦
	    private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(10);
	    private final Player player;

	    public SharedScheduler(Player player) {
			super();
			this.player = player;
		}

}
*/
//package trashBin;


