package taeyoun.starcraft.system;

public class Player {
	
	private int minerals;		//사용자 미네랄
	private int gas;			//사용자 가스
	private int population;		//사용자 인구수
	
	public int getMinerals() {
		return minerals;
	}
	public void setMinerals(int minerals) {
		this.minerals = minerals;
	}
	public int getGas() {
		return gas;
	}
	public void setGas(int gas) {
		this.gas = gas;
	}
	public int getPopulation() {
		return population;
	}
	public void setPopulation(int population) {
		this.population = population;
	}
	
	public boolean canProduce(int mineral, int gas, int population) {
		if(this.minerals < mineral) return false;	//미네랄 부족
		if(this.gas < gas) return false;			//가스 부족
		if(this.population < population) return false;	//인구 부족
		return true;	//생산실행!
	}
	
	
	
}
