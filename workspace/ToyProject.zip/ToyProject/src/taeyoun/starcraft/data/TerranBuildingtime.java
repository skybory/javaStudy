package taeyoun.starcraft.data;
//아직미사용
public class TerranBuildingtime {

		public static final int COMMANDCENTER_TIME = 75;
		
		public static final int SUPPLYDEPOT_TIME = 25;
		
		public static final int REFINERY_TIME = 25;
		
		public static final int BARRACK_TIME = 50;
		
		public static final int ENGINEERINGBAY_TIME = 38;
		
		public static final int ACADEMY_TIME = 50;
		
		public static final int FACTORY_TIME = 50;
		
		public static final int STARPORT_TIME = 44;
		
		public static final int ARMORY_TIME = 50;
		
	}

