package taeyoun.starcraft.Interface;
//인터페이스를 써야할까..
public interface move {
	void move();
}
