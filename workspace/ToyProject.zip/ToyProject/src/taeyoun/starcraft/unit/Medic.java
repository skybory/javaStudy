package taeyoun.starcraft.unit;

public class Medic extends Unit{

	public Medic() {
		super("medic",50, 25, 1, 60);
	}

}
