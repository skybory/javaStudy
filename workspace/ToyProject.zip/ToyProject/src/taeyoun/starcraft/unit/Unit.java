package taeyoun.starcraft.unit;

public class Unit {
	
	private String name;
	private int mineralCost;
	private int gasCost;
	private int populationCost;
	private int maxHp;
	private int currentHp;
	
	public Unit(String name, int mineralCost, int gasCost, int populationCost, int maxHp) {
		super();
		this.name = name;
		this.mineralCost = mineralCost;
		this.gasCost = gasCost;
		this.populationCost = populationCost;
		this.maxHp = maxHp;
		this.currentHp = maxHp;
	}

	public String getName() {
		return name;
	}

	public int getMineralCost() {
		return mineralCost;
	}

	public int getGasCost() {
		return gasCost;
	}

	public int getPopulationCost() {
		return populationCost;
	}

	public int getMaxHp() {
		return maxHp;
	}

	public int getCurrentHp() {
		return currentHp;
	}

	public void setCurrentHp(int currentHp) {
		this.currentHp = currentHp;
	}

	
}
