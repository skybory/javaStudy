package taeyoun.starcraft.unit;

public class Marine extends Unit{
	
	public Marine() {
		//유닛이 가져야 할 정보
		//이름,미네랄가격,가스가격,인구수,체력,공격력,방어력
		super("marine",50, 0, 1, 40);
		System.out.println("마린입니다");
	}

}
