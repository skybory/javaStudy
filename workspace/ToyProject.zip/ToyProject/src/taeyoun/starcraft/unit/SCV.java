package taeyoun.starcraft.unit;
import taeyoun.starcraft.data.TerranUnitPrice;

public class SCV extends Unit {
	public SCV() {
		super("SCV",50,0,1,60);
	}

}
