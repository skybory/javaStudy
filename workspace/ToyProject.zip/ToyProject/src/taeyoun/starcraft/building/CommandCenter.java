package taeyoun.starcraft.building;

import taeyoun.starcraft.system.Player;
import taeyoun.starcraft.unit.Unit;
import taeyoun.starcraft.unit.Marine;
import taeyoun.starcraft.unit.SCV;
public class CommandCenter extends Building{

	public CommandCenter() {
		super("Terran Comman Center", 400, 0, 2000, 2000);
		System.out.println("커멘드센터입니다");
	}
	//Unit 형태의 값을 리턴하는 produce 메서드 실행.
	//Unit unit 값을 받았을 때, 오 씨발 이래서 Building칸에 넣었구나.
	//CommandCenter는 Building을 상속받았으니 produce기능이 있어.
	//상속받은걸 쓰려면..
	
	
	public void produce_SCV() {
		Unit unit = produce(new SCV());
		System.out.println("SCV가 생성되었습니다.");
	}
	
	/*
	switch (scan) {
	case s :
		produce (SCV);
		break;
	}
	
	public Unit produce(Unit SCV) {
		return unit;
	}
*/


}
