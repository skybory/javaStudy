package taeyoun.starcraft.building;

import taeyoun.starcraft.system.Player;
import taeyoun.starcraft.unit.Unit;

public class Building {
	//private String playerName;
	private String name;
	private int mineralCost;
	private int gasCost;
	private int maxHp;
	private int currentHp;
		
	public Building(String name, int mineralCost, int gasCost, int maxHp, int currentHp) {
		
		super();
		this.name = name;
		this.mineralCost = mineralCost;
		this.gasCost = gasCost;
		this.maxHp = maxHp;
		this.currentHp = currentHp;
	}

	
	//public String getPlayerName() {
	//	return playerName;
	//}

	//public void setplayerName(String playerName) {
	//		this.playerName = playerName;
	//	}
	
	
	public String getName() {
		return name;
	}

		
	public void setName(String name) {
		this.name = name;
	}

	public int getMineralCost() {
		return mineralCost;
	}

	public void setMineralCost(int mineralCost) {
		this.mineralCost = mineralCost;
	}

	public int getGasCost() {
		return gasCost;
	}

	public void setGasCost(int gasCost) {
		this.gasCost = gasCost;
	}

	public int getMaxHp() {
		return maxHp;
	}

	public void setMaxHp(int maxHp) {
		this.maxHp = maxHp;
	}

	public int getCurrentHp() {
		return currentHp;
	}

	public void setCurrentHp(int currentHp) {
		this.currentHp = currentHp;
	}

		private Player player;	//Player 클래스의 객체 player 생성
	
	public Unit produce(Unit unit) {	//Unit 타입을 return하는 produce메서드를 호출, 파라미터는 Unit 타입의 unit을 받음.
		//플레이어 클래스에서, 플레이어가 가진 돈과 비교하여 지불금액이 나오면
		if(getPlayer().canProduce(unit.getMineralCost(), unit.getGasCost(), unit.getPopulationCost())) {
			//unit 을 리턴하고(넣은 값을 그대로 리턴하고)
			return unit;
			
		}
		return null;
		//살수없으면 null을 리턴함.
	}

	//이걸 Application에서 Building 으로 옮겼는데, produce() 메서드랑 같이 실행되야 한다고 생각.
	
	/*if(unit != null) {
		System.out.println(unit.getName()+"이 생성되었습니다.");
	}else {
		System.out.println("생성에 실패했습니다.");
	}
	*/

	public Player getPlayer() {
		return player;
	}


	public void setPlayer(Player player) {
		this.player = player;
	}
	

}
