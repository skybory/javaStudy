package taeyoun.starcraft.building;

import taeyoun.starcraft.system.Player;

public class Barracks extends Building {
//(String name, int mineralCost, int gasCost, int maxHp, int currentHp) {
//배럭 이름, 미네랄가격, 가스가격, 최대체력, 현재체력
	//생산자로 만들어둠. 대신 파라미터는 없음.
	public Barracks() {
		super("Terran Barracks", 150, 0, 1000, 1000);
		//배럭스 만들면 배럭스 데이터값이 위와 같이 설정됨.
	}

	
	
}
