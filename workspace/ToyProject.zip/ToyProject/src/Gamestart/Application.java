package Gamestart;

import taeyoun.starcraft.system.Player;
import taeyoun.starcraft.unit.Marine;
import taeyoun.starcraft.unit.Unit;
import taeyoun.starcraft.building.Barracks;
import taeyoun.starcraft.building.Building;
import taeyoun.starcraft.building.CommandCenter;

public class Application {
	public static void main(String[] args) {
		
		Player p1 = new Player();	//미네랄,가스,인구수 라는  정보를 저장할 수 있는 Player p1 생산
		p1.setMinerals(99999);			//p1의 미네랄 99999으로 설정
		p1.setGas(88888);				//p1의 가스 88888으로 설정
		p1.setPopulation(200);		//p1의 인구수 200로 설정
		
		//건물 객체를 생성할꺼임.
		//가장 간단한 배럭을 생성하자면. 어떻게 해야할까?
		//당연히 그냥 배럭을 만들면 됨. 그럼 뭐해야해?
		//p1이 가진 돈이랑 배럭의 가격을 비교해야겠지.
		//어떻게 비교하는데?
		//잘생각해봐. p1이 가진 돈을 불러오고, 배럭의 입력값을 가져와서 비교하면 돼.
		//build 메서드를 가져와서 배럭을 지어. 어떻게 하면 될까?
		//빌드 배럭스 박으면되지. 
		//빌드는 SCV만 할 수 있으니깐, 먼저 SCV를 불러오자.
		//SCV 는 커맨드센터에서 나오고, 커멘드센터 하나는 그냥 기본으로 줘.
		
		CommandCenter c1 = new CommandCenter();
		//자 커멘드센터 만들었어
		//이제 뭐해야해? SCV 뽑아야지 뭘 마린을 뽑냐.
		//SCV는 누가뽑아? 커멘드센터가 뽑지. 그럼 produce 기능을 커맨드센터가 제공해야할꺼야.
		c1.produce(null);
		//build(Barracks);
		
		// 만약 팩토리를 생성하고 싶다면 new Factorys(p1); 로 이부분만 교체하면 됨
		Building building = new Barracks();
		
		//Building building = new Barracks(p1);
		
		// 마린이 아니라 medic을 생성하고 싶다면 파라미터만 new Medic()으로 바꿔주면 됨
				Unit unit = building.produce(new Marine());
				//유닛 클래스의 unit 에 생산합니다(마린) 을 넣음
				//만약 생산이 되었다면 마린이 두개일꺼야
				//두개가 안만들어짐. 뜯어고쳐야해.
				
				//유닛클래스에 unit 객체에 produce메서드의 결과값을 대입함.
				
		
	}
}
